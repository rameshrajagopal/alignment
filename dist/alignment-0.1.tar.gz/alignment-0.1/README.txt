A small commandline application which sets up arbitory solar system based on
the config file provided. It also prints the alignment of the planets based on
plugins provided.
